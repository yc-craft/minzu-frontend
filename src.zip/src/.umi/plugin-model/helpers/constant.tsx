// @ts-nocheck
import React from 'react';

export const UmiContext = React.createContext({});
