import _ from 'E:/西南民族大学！/大三下/oracle/期末大作业/minzu-frontend/node_modules/antd/es/avatar';
export default _;
export * from 'E:/西南民族大学！/大三下/oracle/期末大作业/minzu-frontend/node_modules/antd/es/avatar';
