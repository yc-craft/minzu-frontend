import _ from '@ant-design/icons/TableOutlined';
export default _;
