// @ts-nocheck
/**
 * A component that provides points for umi ui
 */
import React from 'react';

export interface UmiUIFlagProps {
  inline?: boolean;
}

export const UmiUIFlag: React.FunctionComponent = () => {
  return <></>;
};

UmiUIFlag.displayName = 'INSERT_BLOCK_PLACEHOLDER';
